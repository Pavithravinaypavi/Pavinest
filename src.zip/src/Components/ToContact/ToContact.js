import { useState } from 'react'
import './ToContact.css'

function ToContact(){

    return(
        <div className='fixed inset-0 bg-black bg-opacity-30 backdrop-blur-sm'>
            model
        </div>
    )
}

export default ToContact
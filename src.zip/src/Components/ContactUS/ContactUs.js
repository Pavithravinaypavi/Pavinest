function ContactUs() {
    return(
        <div style={{'backgroundColor': 'lightgray', 'padding': '2em'}}>
            <div className="container-fluid">
                <h4 className="text-center">Call Us On: +91-8880707646 / +91-8618926494</h4>
            </div>
        </div>
    )
}

export default ContactUs